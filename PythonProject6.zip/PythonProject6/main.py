def f(x):
    return (1.2 + 2 * x  2) / (3.1 + x  3)


def simpson_detailed(a, b, m, step_name):
    n = 2 * m  # Кількість розбиттів
    h = (b - a) / n  # Крок

    print(f" {step_name} | Кількість розбиттів n = {n} | Крок h = {h:.2f}")
    print(f"{'=' * 60}")

    print(f"{'i':^5} | {'x_i':^10} | {'y_i = f(x)':^15}")
    print("-" * 36)

    y_values = []
    x_values = []

    for i in range(n + 1):
        x_curr = a + i * h
        y_curr = f(x_curr)
        x_values.append(x_curr)
        y_values.append(y_curr)
        print(f"{i:^5} | {x_curr:^10.4f} | {y_curr:^15.5f}")

    sum_edges = y_values[0] + y_values[-1]

    sum_odd = sum(y_values[1:n:2])

    sum_even = sum(y_values[2:n:2])

    result = (h / 3) * (sum_edges + 4 * sum_odd + 2 * sum_even)

    print("-" * 36)
    print(f"Проміжні суми:")
    print(f" > y_0 + y_n (крайні): {sum_edges:.5f}")
    print(f"Результат {step_name}: {result:.6f}")
    print(f"{'=' * 60}")

    return result


a = 0
b = 1.2

res_1 = simpson_detailed(a, b, m=2, step_name="ітерація 1")

res_2 = simpson_detailed(a, b, m=4, step_name="ітерація 2")

print(" Правило Рунге")
print(f"{'=' * 60}")

R2 = abs(res_2 - res_1) / 15
tolerance = 0.001

print(f"Похибка R2 = |{res_2:.6f} - {res_1:.6f}| / 15")
print(f"Значення R2 = {R2:.3e} (або {R2:.8f})")
print(f"Допустима похибка = {tolerance}")

if R2 < tolerance:
    print("\nВисновок: R2 < 0.001")
    print(f"Висновок інтегралу: {res_2:.6f}")
else:
    print("\nВисновок: точність не досягнута, потрібно зменшувати крок")